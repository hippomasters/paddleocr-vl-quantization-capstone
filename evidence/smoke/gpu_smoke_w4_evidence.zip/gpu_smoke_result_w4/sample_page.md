## SMOKE TEST DOCUMENT

Invoice No: TEST-001

Date: 2026-10-13



<table><tr><td>Item</td><td>Quantity</td><td>Price</td></tr><tr><td>Sample notebook page</td><td>1</td><td>10.00</td></tr></table>

Total: 10.00

This synthetic page tests document parsing.